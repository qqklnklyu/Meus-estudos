


















geral = {

"vip" :["Maria","tomas","vini"],
"menores":[],
"pagaram":[],
"entraram":[]

}
def verificação():
    idade=int(input("qual a sua idade:"))

    if idade < 18:

            print("Va embora")
            geral["menores"].append(nome)

    else:
            dinheiro = float(input("no total são 50 reais, digite quanto você tem:"))
            if dinheiro >= 50:
                print("pode entrar:")
                geral["entraram"].append(nome)
                geral["pagaram"].append(nome)
            else:
                 print("va embora você não tem dinheiro o suficiente:")
            

    

while True:
    conti = int(input("proximo:(1=sim 0 0=não)"))
    if conti == 0:
         break
    else:
     nome = input("qual o seu nome:")
     if nome in geral["vip"]  and nome not in geral["entraram"]:
        
         print("pode entrar:")
         geral["entraram"].append(nome)

     elif  nome in geral["vip"]  and nome in geral["entraram"]:

         print(f"{nome} ja entrou na festa:")
         verificação()
            
     elif nome not in geral["vip"]  and nome in geral["entraram"]:
         
         print(f"{nome} ja entrou na festa:")
         verificação()

     else:
         
         verificação()

print(geral)



     

    

