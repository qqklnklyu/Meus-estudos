def ação ():
    print("ERROR!!!")

   
ação()  
ação() 
ação() 


pro = input("digite o nome do produto")
quant = int(input("digite a quantidde atual:"))
def estoque(pro,quant):
    if quant < 10:
        print(f"Repor {pro} pois a apenas {quant} no estoque:")
    else:
        print(f"estoque atual dentro dos limites")
estoque(pro,quant)

dolar = float (input("digite a quantidade de dolares atual:"))
real = 0
def convert(dolar):
    return dolar * 5.00
    
real = convert(dolar)
print(f"{real}, em reais")

notas = []
while True:
  nota = float(input("digite a nota:"))
  notas.append(float(nota))
  no = int(input("deseja parar:1 = sim 0 = não"))
  if no == 1:
            break

def media(notas):
    return sum(notas) / len(notas)

notas = media(notas)
print(f"{notas} é a media de todas as notas:")

#desafio do dia
i=0
litfun = []
def cadfunc(litfun):
     
          funcionario = input("qual o nome:")
          cargo = input("qual o cargo:")
          salario = float(input("qual o salario:"))
          funcionario = {"nome":funcionario,"cargo":cargo,"salario":salario}
          litfun.append(funcionario)
def list(litfun):
     for i in range(0,len(litfun)):
          print(litfun[i])
          
while True:
     res = input("o que deseja: 1=cadastro 2=listagem 3=sair")
     if res == "3":
          break
     elif res == "1":
          cadfunc(litfun)
     elif res == "2":
          list(litfun)
     else:
           print("escolha uma das opções demonstradas:")

print("obrigado por excolher nosso serviços")
     
          