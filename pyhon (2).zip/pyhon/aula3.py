# Repete de 0 até 4 (5 vezes)
for i in range(5):
    print(f"Processando item {i}")

for i in range(10):
    print(f"numerando computador {i}")
total=0
for i in range(10):
    valor=float(input(f"qual o preço do produto{i}:"))
    total= total + valor
print(f"você lucrou",total)    

senha_correta = "123"
tentativa = ""

while tentativa != senha_correta:
    tentativa = input("Digite a senha: ")

print("Acesso liberado!")

preção = 0

while preção != 30:
    print("enchendo, preção atual em ",preção)
    preção = preção + 1
print("o pineu esta cheio")   

botao = 0 
for i in range(1, 10):
    botao=int(input(f"estamos no {i} andar, deseja apertar o botão de emergencia.(1 para sim e 0 para não)"))
    if botao == 1:
        break # Para no 5
    print(f"paramos no andar {i}")

for i in range (1,21):
    if i == 7:
        continue
    if i == 13:
        continue
    print(i)


carros=["carro1","carro2","Carro3"]
carrope = int(input("digite um numero de 0 a 2: "))
print(f"seu carro é o ",carros[carrope])


compras = []
compra = 0
while compra < 1:
   prod = input("digite o nome do produto")
   compras.append(prod)
   compra = int(input("Deseja continuar:(digite 0 pra sim e 1 para não)"))
  
print(compras)
print(f"O total de compras foi de ",len(compras)," itens:")


tarefas=["estudar","trabalhar","exercicios"]
print(tarefas)


while True :
  feito = int(input("qual tarefa ja foi feita:"))
  tarefas.pop(feito)

  if len(tarefas) > 0:
   for i in range(len(tarefas)):
    print(tarefas[i],i)
  else:
    break
  
print("você completou todas a tarefas, parabens!")


banidos = ["joão","Rodoufo","rafael"]

nome = input("qual seu nome:")
if nome in banidos:
  print("acesso negado!")
else:
  print("bem vindo!")

numeros = []
for i in range(1,6):
    numero = int(input("digite um numero:"))
    numeros.append(numero)

print(max(numeros))
print(min(numeros))
print(sum(numeros))

#desafio 1

vip = ["rodoufo","maria", "jose"]

nome = input("qual seu nome:")

if nome in vip:
  print("pode entrar")
else:
  idade = int(input("qual a sua idade:"))
  if idade >= 18:
    valor = int(input("pague 50,00.Você tem este dinhero:(1 para sim e 0 para não)"))
    if valor == 0:
      print("va embora")
    elif valor == 1:
      print("pode entrar")
  else:
    print("vai embora!")    

#desafio 2


