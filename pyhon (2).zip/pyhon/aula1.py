#exemcicios 1:
 
palcha = "Abóbora"
pal = input("qual é a palavra cahve:")
if palcha == pal:
   print("pode entrar")
else:
   print("va embora")  


#exercicio 2

estoatu = 120

carrega = int(input("quantos celulares chegaram:"))

estototal = carrega + estoatu
print("atualmente temos",estototal,"celulares em estoque")

# exercicio  3

precocarne = 35.90
quantcarne = float(input("quanto de carne você vai querer:"))

preco = quantcarne * precocarne
print(f"total a pagar sera {preco:.2f}")

#exercicio 4

temp =  int(input("qual a temperatura atual:"))
if temp > 40:
   print("nivel de temperatura critico")
elif temp <=40 >= 30:
   print("nevil de tempertatura alto")
else:
   print("temperatura normal")


#exercicio 5 

ovoscaixa = 6
ovopro = int(input("quantos ovos foram produzidos:"))
sobra = ovopro % ovoscaixa
if sobra == 0:
   print("todos os ovos estão em suas respectivas caixas")
elif sobra > 0:
   print("ira ficar no total ",sobra,"ovos fora das caixas")

# exrcicio 6

quanthoras = int(input("quantas horas de voo vocÊ tem:"))
breve = input("possue o breve:(resónda com sim ou não)")
if quanthoras > 500 and breve == "sim":
   print("autorizdo a pilotar")
else:
   print("não autorizado")

#os problemas grande ainda vou resolver

