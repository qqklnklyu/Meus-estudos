quantpeca = int(input("qual a quantidade de peças serão produzidas:"))
for i  in range(1,quantpeca+1):
    pesopeca = int(input("qua, o peso da peça em gramas:"))
    if pesopeca < 50:
     print ("peça muito pequena descartar")
     continue
    elif pesopeca > 100:
       print("peça muito pesada descartar")
       continue
    else:
       print(f"peça{i} aprovada com peso de ",pesopeca)
       pesopeca = 0
       
    
meta = int(input("digite sua meta economica:"))
metaatu = 0
while metaatu < meta:
  deposito = int(input("quanto quer depositar hoje:"))
  metaatu = metaatu + deposito
  distan = meta - metaatu
  if metaatu < meta:
   print(f"você depositou",deposito,", sua meta é de ",meta,"faltam ",distan," para chegar:")
  else:
    print("parabens você atingiu sua meta, agora você possue ", metaatu)
    
    total = 0
r=0
while True:
  preco = int(input("Digite o preço do produto:"))
  nome = input("digite o nome do produto:(caso deseje parar digite 1)")

  r = r +1
  print(f"produto de nome ",nome," de custo de ",preco)
  if nome == "1":
    break
  else:
   total = total+ preco  

print(f"devera pagar no total ",total)
    
  
    

  