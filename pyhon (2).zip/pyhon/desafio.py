#desafio 1
preco = 25
filme = input("qual o nome do filme:")
idade = int(input("qual asa idade:"))
if idade < 16:
    print("Acesso negado por idade")
else:
    dinheiro = float(input("ficou 25,00 reais, quanto dinheiro você tem na carteira"))
    if dinheiro < preco:
        falta = preco - dinheiro
        print(f"saldo insuficiente, faltam{falta:.2f}")
    else:
        print("Ticket impresso para ",filme)
    
#desafio 2

precogaso = float(input("qual o preço da gasolina:"))
precoalcoo = float(input("qual o preço dp alcool:")) 
porcento = precogaso * 0.70

if precoalcoo <= porcento:
    print("é melhor comprar alcool")
    litros = int(input("quantos reais de alcool ira colocar:"))
    total = litros / precoalcoo
elif precoalcoo > porcento:
    print("É melhor comprar gasolina")
    litros = int(input("quantos reais de gasolina ira colocar:"))
    total = litros / precogaso

print(f"vocÊ ira pagar por{total:.2}")