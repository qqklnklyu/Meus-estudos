#carro = {"marca": "Ford", "modelo": "Mustang", "ano": 1964}
#print(carro["modelo"])

#pessoa = {"nome":"jose", "cidade": "sergipe", "profição": "TI"}
#print(pessoa["cidade"])


#### 2. Alterando e Adicionando


usuario = {"login": "admin", "status": "ativo"}
usuario["status"] = "inativo" # Altera
usuario["ultimo_acesso"] = "10/01/2026" # Adiciona
print(usuario)


produto = {"nome":"sabão","preço":42}
print(produto)
produto["preço"] = int(input("digite o novo preço:"))
produto["desconto"] = 5
print(produto)
#### 3. Dicionário com Listas

#cardapio = {
#    "sucos": ["Laranja", "Uva", "Abacaxi"],
#    "precos": [5, 6, 7]
#}
#print(cardapio["sucos"][0]) # Laranja

#escolas = {
#"alunos":["roberto","joão", "maria"]
#}
#print(escolas["alunos"])
#escolas["alunos"[3]] ="roberta" 
#print(escolas["alunos"])
turma = [] # Lista que guardará os dicionários

for i in range(3):
    nome = input("Nome do aluno: ")
    nota = int(input("Nota: "))
    # Cria um dicionário para este aluno específico
    aluno = {"nome": nome, "nota": nota}
    # Adiciona o dicionário à lista
    turma.append(aluno)

print(turma)

